import dns from 'node:dns';
import net from 'node:net';
import https from 'node:https';
import type { IncomingHttpHeaders } from 'node:http';
import ipaddr from 'ipaddr.js';

export type ProbeErrorCode = 'blocked_target' | 'timeout' | 'network' | 'too_many_redirects' | 'bad_redirect';

export class ProbeError extends Error {
  constructor(public code: ProbeErrorCode, message?: string) {
    super(message ?? code);
  }
}

export type ProbeResult = {
  finalUrl: string;
  status: number;
  contentType: string | null;
  contentLength: number | null;
};

// Netlify synchronous functions time out at 10 s by default, so the whole probe (all redirects) gets a hard budget below that.
const TIMEOUT_MS = Number(process.env.PROBE_TIMEOUT_MS ?? 4000);
const TOTAL_BUDGET_MS = Number(process.env.PROBE_TOTAL_MS ?? 8000);
const MAX_REDIRECTS = 3;

/** True only for globally routable unicast addresses (blocks private, loopback, link-local, CGNAT, multicast, etc.). */
export function isPublicIp(ip: string): boolean {
  try {
    let addr = ipaddr.parse(ip);
    if (addr.kind() === 'ipv6' && (addr as ipaddr.IPv6).isIPv4MappedAddress()) {
      addr = (addr as ipaddr.IPv6).toIPv4Address();
    }
    return addr.range() === 'unicast';
  } catch {
    return false;
  }
}

/**
 * DNS lookup that validates every resolved address at connect time.
 * Because the socket connects to the address we validated, DNS rebinding cannot swap in a private IP afterwards.
 */
export function safeLookup(
  hostname: string,
  options: dns.LookupOptions,
  callback: (err: NodeJS.ErrnoException | null, address?: string | dns.LookupAddress[], family?: number) => void,
): void {
  dns.lookup(hostname, { ...options, all: true }, (err, addresses) => {
    if (err) return callback(err);
    const list = addresses as dns.LookupAddress[];
    if (list.length === 0 || list.some((a) => !isPublicIp(a.address))) {
      return callback(new Error('blocked_address'));
    }
    if (options.all) return callback(null, list);
    callback(null, list[0].address, list[0].family);
  });
}

export function assertAllowedTarget(u: URL): void {
  if (u.protocol !== 'https:') throw new ProbeError('blocked_target');
  if (u.username || u.password) throw new ProbeError('blocked_target');
  if (u.port && u.port !== '443') throw new ProbeError('blocked_target');
  const host = u.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (net.isIP(host) && !isPublicIp(host)) throw new ProbeError('blocked_target');
  if (host === 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) throw new ProbeError('blocked_target');
}

type Raw = { status: number; headers: IncomingHttpHeaders };

function requestOnce(u: URL, method: 'HEAD' | 'GET', timeoutMs: number): Promise<Raw> {
  return new Promise((resolve, reject) => {
    const req = https.request(
      u,
      {
        method,
        // Cast: Node's typings for `lookup` are stricter than its runtime behaviour.
        lookup: safeLookup as never,
        timeout: timeoutMs,
        headers: {
          'user-agent': 'DownCloudToolsLinkChecker/1.0',
          accept: '*/*',
          ...(method === 'GET' ? { range: 'bytes=0-0' } : {}),
        },
      },
      (res) => {
        // We only need headers. Never read the body.
        res.destroy();
        resolve({ status: res.statusCode ?? 0, headers: res.headers });
      },
    );
    req.on('timeout', () => req.destroy(new ProbeError('timeout')));
    req.on('error', (e) => {
      if (e instanceof ProbeError) return reject(e);
      if (/blocked_address/.test(e.message)) return reject(new ProbeError('blocked_target'));
      reject(new ProbeError('network'));
    });
    req.end();
  });
}

function parseSize(res: Raw): number | null {
  const range = res.headers['content-range'];
  if (res.status === 206 && typeof range === 'string') {
    const m = /\/(\d+)$/.exec(range);
    if (m) return Number(m[1]);
  }
  const len = res.headers['content-length'];
  if (typeof len === 'string' && /^\d+$/.test(len) && res.status !== 206) return Number(len);
  return null;
}

/** Inspect a URL's headers without downloading it. Every redirect hop is re-validated. */
export async function probe(start: URL): Promise<ProbeResult> {
  let u = new URL(start.href);
  const deadline = Date.now() + TOTAL_BUDGET_MS;
  const budget = () => {
    const left = deadline - Date.now();
    if (left <= 250) throw new ProbeError('timeout');
    return Math.min(TIMEOUT_MS, left);
  };
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    assertAllowedTarget(u);
    let res = await requestOnce(u, 'HEAD', budget());
    // Some servers reject HEAD; retry with a one-byte ranged GET (body is never read).
    if ([403, 405, 501].includes(res.status)) res = await requestOnce(u, 'GET', budget());

    const location = res.headers.location;
    if (res.status >= 300 && res.status < 400 && location) {
      try {
        u = new URL(location, u);
      } catch {
        throw new ProbeError('bad_redirect');
      }
      continue;
    }
    const ct = res.headers['content-type'];
    return {
      finalUrl: u.href,
      status: res.status,
      contentType: typeof ct === 'string' ? ct.split(';')[0].trim().toLowerCase() : null,
      contentLength: parseSize(res),
    };
  }
  throw new ProbeError('too_many_redirects');
}
