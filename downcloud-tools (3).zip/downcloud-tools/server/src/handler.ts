import { createAnalyzer, type Analyzer } from './registry';
import { AnalyzeError } from './providers/types';

export type HandlerOptions = {
  analyzer?: Analyzer;
  rateLimitMax?: number;
  /** If non-empty, browser requests carrying an Origin header must match one of these. */
  allowedOrigins?: string[];
  now?: () => number;
};

const MAX_BODY_BYTES = 4096;

const json = (status: number, body: unknown, extra: Record<string, string> = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', ...extra },
  });

const fail = (status: number, code: string, message: string, extra: Record<string, string> = {}, officialUrl?: string) =>
  json(status, { ok: false, error: { code, message, officialUrl } }, extra);

/**
 * Fixed-window limiter held in memory. On Netlify each function instance has its own counter, so this is a
 * best-effort brake against bursts, not a hard global limit. See the README for adding Netlify-level rate limiting.
 */
export function createRateLimiter(max: number, windowMs: number, now: () => number = Date.now) {
  const hits = new Map<string, { count: number; resetAt: number }>();
  return (key: string): { allowed: boolean; retryAfterSeconds: number } => {
    const t = now();
    if (hits.size > 5000) for (const [k, v] of hits) if (v.resetAt <= t) hits.delete(k);
    const entry = hits.get(key);
    if (!entry || entry.resetAt <= t) {
      hits.set(key, { count: 1, resetAt: t + windowMs });
      return { allowed: true, retryAfterSeconds: 0 };
    }
    entry.count++;
    return { allowed: entry.count <= max, retryAfterSeconds: Math.max(1, Math.ceil((entry.resetAt - t) / 1000)) };
  };
}

/** Framework-independent handler for POST /api/analyze: takes a Web Request, returns a Web Response. */
export function createAnalyzeHandler(opts: HandlerOptions = {}) {
  const analyzer = opts.analyzer ?? createAnalyzer();
  const allowedOrigins =
    opts.allowedOrigins ?? (process.env.ALLOWED_ORIGINS ?? '').split(',').map((s) => s.trim()).filter(Boolean);
  const limiter = createRateLimiter(opts.rateLimitMax ?? Number(process.env.RATE_LIMIT_PER_MINUTE ?? 20), 60_000, opts.now);

  return async (req: Request, clientIp: string): Promise<Response> => {
    if (req.method !== 'POST') return fail(405, 'method_not_allowed', 'Use POST.', { allow: 'POST' });

    const origin = req.headers.get('origin');
    if (allowedOrigins.length > 0 && origin && !allowedOrigins.includes(origin)) {
      return fail(403, 'origin_not_allowed', 'This origin is not allowed to use the API.');
    }

    const rl = limiter(clientIp || 'unknown');
    if (!rl.allowed) {
      return fail(429, 'rate_limited', 'Too many requests. Please wait a minute and try again.', { 'retry-after': String(rl.retryAfterSeconds) });
    }

    let text: string;
    try {
      text = await req.text();
    } catch {
      return fail(400, 'bad_request', 'The request could not be read.');
    }
    if (text.length > MAX_BODY_BYTES) return fail(400, 'bad_request', 'The request is too large.');

    let body: unknown;
    try {
      body = JSON.parse(text);
    } catch {
      return fail(400, 'bad_request', 'The request body must be JSON like {"url":"https://..."}.');
    }

    try {
      const result = await analyzer((body as { url?: unknown } | null)?.url);
      return json(200, { ok: true, result });
    } catch (e) {
      if (e instanceof AnalyzeError) return fail(e.status, e.code, e.message, {}, e.extra?.officialUrl);
      // Log only the error type, never the submitted URL.
      console.error('analyze failed:', e instanceof Error ? e.name : 'unknown');
      return fail(500, 'server_error', 'Something went wrong while analyzing that link.');
    }
  };
}
