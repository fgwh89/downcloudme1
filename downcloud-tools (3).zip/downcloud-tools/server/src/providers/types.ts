export type MediaFormat = {
  id: string;
  label: string;
  container: string;
  sizeBytes: number | null;
  url: string;
};

export type AnalyzeResult = {
  provider: string;
  providerName: string;
  title: string;
  source: string;
  thumbnail: string | null;
  durationSeconds: number | null;
  formats: MediaFormat[];
  notes: string[];
};

export class AnalyzeError extends Error {
  constructor(
    public code: string,
    message: string,
    public status = 422,
    public extra?: { officialUrl?: string },
  ) {
    super(message);
  }
}

export interface Provider {
  id: string;
  name: string;
  /** Empty array means "any public host" (subject to SSRF controls). */
  domains: string[];
  limitations: string[];
  matches(url: URL): boolean;
  analyze(url: URL): Promise<AnalyzeResult>;
}
