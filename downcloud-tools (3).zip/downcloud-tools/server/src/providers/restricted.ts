import type { Provider } from './types';
import { AnalyzeError } from './types';

export type RestrictedPlatform = {
  name: string;
  domains: string[];
  officialUrl: string;
  reason: string;
};

/**
 * Platforms this service deliberately does NOT extract from. Their terms prohibit unauthorized downloading
 * and/or they use access controls we will not bypass. Users are pointed to the official site instead.
 */
export const restrictedPlatforms: RestrictedPlatform[] = [
  { name: 'YouTube', domains: ['youtube.com', 'youtu.be', 'youtube-nocookie.com'], officialUrl: 'https://www.youtube.com/', reason: 'YouTube only permits downloads through its own features (for example YouTube Premium offline mode or a creator enabling downloads).' },
  { name: 'SoundCloud', domains: ['soundcloud.com'], officialUrl: 'https://soundcloud.com/', reason: 'SoundCloud allows downloads only where the creator has enabled them or through its official offline features.' },
  { name: 'TikTok', domains: ['tiktok.com'], officialUrl: 'https://www.tiktok.com/', reason: 'TikTok offers a built-in download option only on videos where the creator allows it.' },
  { name: 'Instagram', domains: ['instagram.com'], officialUrl: 'https://www.instagram.com/', reason: 'Instagram does not provide a public download mechanism for other people’s content.' },
  { name: 'Facebook', domains: ['facebook.com', 'fb.watch'], officialUrl: 'https://www.facebook.com/', reason: 'Facebook does not provide a public download mechanism for other people’s content.' },
  { name: 'X (Twitter)', domains: ['twitter.com', 'x.com'], officialUrl: 'https://x.com/', reason: 'X does not provide a public download mechanism for other people’s content.' },
  { name: 'Vimeo', domains: ['vimeo.com'], officialUrl: 'https://vimeo.com/', reason: 'Vimeo lets video owners decide whether downloads are enabled; the download button appears on the official page when they are.' },
  { name: 'Spotify', domains: ['spotify.com', 'open.spotify.com'], officialUrl: 'https://www.spotify.com/', reason: 'Spotify content is protected by DRM and can only be saved through Spotify Premium offline mode.' },
  { name: 'Netflix', domains: ['netflix.com'], officialUrl: 'https://www.netflix.com/', reason: 'Netflix content is DRM-protected and can only be saved through the official app’s download feature.' },
  { name: 'Twitch', domains: ['twitch.tv'], officialUrl: 'https://www.twitch.tv/', reason: 'Twitch allows broadcasters to download their own past broadcasts from their dashboard.' },
];

export function findRestricted(url: URL): RestrictedPlatform | undefined {
  const host = url.hostname.toLowerCase();
  return restrictedPlatforms.find((p) => p.domains.some((d) => host === d || host.endsWith('.' + d)));
}

/** Throws a helpful error for restricted platforms; used before any provider runs. */
export function assertNotRestricted(url: URL): void {
  const hit = findRestricted(url);
  if (hit) {
    throw new AnalyzeError(
      'platform_not_supported',
      `${hit.name} links are not supported. ${hit.reason}`,
      422,
      { officialUrl: hit.officialUrl },
    );
  }
}

export type { Provider };
