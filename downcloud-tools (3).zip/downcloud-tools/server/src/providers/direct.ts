import type { AnalyzeResult, Provider } from './types';
import { AnalyzeError } from './types';
import { probe, ProbeError, type ProbeResult } from '../ssrf';

const MEDIA_EXTENSIONS = new Set(['mp4', 'm4v', 'webm', 'mkv', 'mov', 'avi', 'mp3', 'm4a', 'aac', 'ogg', 'oga', 'ogv', 'opus', 'wav', 'flac']);

const TYPE_TO_EXT: Record<string, string> = {
  'video/mp4': 'mp4',
  'video/webm': 'webm',
  'video/x-matroska': 'mkv',
  'video/quicktime': 'mov',
  'video/ogg': 'ogv',
  'audio/mpeg': 'mp3',
  'audio/mp4': 'm4a',
  'audio/aac': 'aac',
  'audio/ogg': 'ogg',
  'audio/opus': 'opus',
  'audio/wav': 'wav',
  'audio/x-wav': 'wav',
  'audio/flac': 'flac',
};

const MANIFEST_TYPES = ['application/vnd.apple.mpegurl', 'application/x-mpegurl', 'application/dash+xml'];

export const MAX_FILE_BYTES = Number(process.env.MAX_FILE_BYTES ?? 1024 ** 3); // 1 GiB default

function extensionOf(pathname: string): string | null {
  const m = /\.([a-z0-9]{2,5})$/i.exec(pathname);
  return m ? m[1].toLowerCase() : null;
}

function fileNameOf(pathname: string): string {
  const last = pathname.split('/').filter(Boolean).pop() ?? 'media-file';
  try {
    return decodeURIComponent(last);
  } catch {
    return last;
  }
}

/**
 * Direct media files: an HTTPS link that points straight at a video/audio file.
 * We read only the response headers (HEAD, or a 1-byte ranged GET), so everything returned here is real.
 * The download button points at the host's own URL; this server never proxies the file.
 */
export function createDirectMediaProvider(probeFn: (u: URL) => Promise<ProbeResult> = probe): Provider {
  return {
    id: 'direct-media',
    name: 'Direct media file',
    domains: [],
    limitations: [
      'Only links that point straight at an audio or video file are supported.',
      'Streaming playlists (HLS .m3u8 / DASH .mpd) are not single files and are rejected.',
      'No titles, thumbnails or durations are returned, because plain files do not expose them in headers.',
      'Links that need a login, cookies or signed expiring tokens may fail.',
    ],
    matches: () => true,
    async analyze(url: URL): Promise<AnalyzeResult> {
      let r: ProbeResult;
      try {
        r = await probeFn(url);
      } catch (e) {
        if (e instanceof ProbeError) {
          const map: Record<string, [string, string, number]> = {
            blocked_target: ['blocked_target', 'That address is not allowed. Only public HTTPS websites can be checked.', 400],
            timeout: ['source_timeout', 'The source server took too long to respond. Try again later.', 504],
            network: ['source_unavailable', 'Could not reach the source server. It may be offline or blocking automated requests.', 502],
            too_many_redirects: ['source_unavailable', 'The link redirected too many times.', 502],
            bad_redirect: ['source_unavailable', 'The link redirected to an invalid address.', 502],
          };
          const [code, msg, status] = map[e.code];
          throw new AnalyzeError(code, msg, status);
        }
        throw e;
      }

      if (r.status === 404 || r.status === 410) {
        throw new AnalyzeError('source_gone', 'The file was not found. The link may have expired or been removed.', 404);
      }
      if (r.status === 401 || r.status === 403) {
        throw new AnalyzeError('access_denied', 'The source requires authentication or blocks automated access. Restricted files are not bypassed.', 403);
      }
      if (r.status >= 500 || r.status === 429) {
        throw new AnalyzeError('source_unavailable', 'The source server is unavailable or rate-limiting requests. Try again later.', 502);
      }
      if (r.status < 200 || r.status >= 300) {
        throw new AnalyzeError('source_unavailable', `The source responded with an unexpected status (${r.status}).`, 502);
      }

      const final = new URL(r.finalUrl);
      const type = r.contentType ?? '';
      if (MANIFEST_TYPES.includes(type) || /\.(m3u8|mpd)$/i.test(final.pathname)) {
        throw new AnalyzeError('streaming_manifest', 'This link is a streaming playlist, not a single downloadable file.');
      }

      const urlExt = extensionOf(final.pathname);
      const looksMedia = type.startsWith('video/') || type.startsWith('audio/') || type === 'application/ogg' ||
        (type === 'application/octet-stream' && urlExt !== null && MEDIA_EXTENSIONS.has(urlExt));
      if (!looksMedia) {
        throw new AnalyzeError('not_media', 'This link does not point to an audio or video file (it returned a web page or another file type).');
      }

      if (r.contentLength !== null && r.contentLength > MAX_FILE_BYTES) {
        throw new AnalyzeError('too_large', `The file is larger than the ${Math.round(MAX_FILE_BYTES / 1024 ** 2)} MB limit this service allows.`, 413);
      }

      const ext = TYPE_TO_EXT[type] ?? urlExt ?? 'bin';
      const notes: string[] = [];
      if (r.contentLength === null) notes.push('The server did not report a file size.');

      return {
        provider: 'direct-media',
        providerName: 'Direct media file',
        title: fileNameOf(final.pathname),
        source: final.hostname,
        thumbnail: null,
        durationSeconds: null,
        formats: [
          {
            id: 'original',
            label: `${ext.toUpperCase()} (original file)`,
            container: ext,
            sizeBytes: r.contentLength,
            url: final.href,
          },
        ],
        notes,
      };
    },
  };
}
