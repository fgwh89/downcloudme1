import type { AnalyzeResult, Provider } from './providers/types';
import { createDirectMediaProvider } from './providers/direct';
import { assertNotRestricted } from './providers/restricted';
import { AnalyzeError } from './providers/types';
import { validateMediaUrl } from '../../shared/url';

export type Analyzer = (rawUrl: unknown) => Promise<AnalyzeResult>;

/** Providers are tried in order; add new adapters to this array (they must be tested before being listed as supported). */
export function createAnalyzer(providers: Provider[] = [createDirectMediaProvider()]): Analyzer {
  return async (rawUrl) => {
    if (typeof rawUrl !== 'string') throw new AnalyzeError('invalid_url', 'A URL is required.', 400);
    const check = validateMediaUrl(rawUrl);
    if (!check.ok) throw new AnalyzeError('invalid_url', check.error, 400);

    assertNotRestricted(check.url);

    const provider = providers.find((p) => p.matches(check.url));
    if (!provider) throw new AnalyzeError('platform_not_supported', 'No supported provider can process this link.');
    return provider.analyze(check.url);
  };
}
