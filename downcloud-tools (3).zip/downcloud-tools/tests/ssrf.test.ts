import { describe, expect, it } from 'vitest';
import { isPublicIp, assertAllowedTarget, ProbeError } from '../server/src/ssrf';

describe('isPublicIp (SSRF guard)', () => {
  it('blocks private, loopback, link-local, CGNAT and metadata addresses', () => {
    for (const ip of ['127.0.0.1', '10.0.0.5', '172.16.4.1', '192.168.1.1', '169.254.169.254', '100.64.0.1', '0.0.0.0', '224.0.0.1', '::1', 'fe80::1', 'fc00::1', '::ffff:127.0.0.1', '::ffff:10.0.0.1']) {
      expect(isPublicIp(ip), ip).toBe(false);
    }
  });
  it('allows public addresses', () => {
    for (const ip of ['8.8.8.8', '1.1.1.1', '93.184.216.34', '2606:4700:4700::1111']) {
      expect(isPublicIp(ip), ip).toBe(true);
    }
  });
  it('rejects garbage', () => {
    expect(isPublicIp('not-an-ip')).toBe(false);
  });
});

describe('assertAllowedTarget', () => {
  const bad = ['http://example.com/a', 'https://example.com:8443/a', 'https://u:p@example.com/a', 'https://127.0.0.1/a', 'https://[::1]/a', 'https://localhost/a', 'https://box.internal/a'];
  for (const u of bad) {
    it(`blocks ${u}`, () => {
      expect(() => assertAllowedTarget(new URL(u))).toThrow(ProbeError);
    });
  }
  it('allows a normal public hostname (resolution is checked at connect time)', () => {
    expect(() => assertAllowedTarget(new URL('https://example.com/a.mp4'))).not.toThrow();
  });
});
