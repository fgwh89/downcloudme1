import { describe, expect, it } from 'vitest';
import { createAnalyzer } from '../server/src/registry';
import { createDirectMediaProvider } from '../server/src/providers/direct';
import { AnalyzeError } from '../server/src/providers/types';
import { ProbeError, type ProbeResult } from '../server/src/ssrf';

const ok = (over: Partial<ProbeResult> = {}) =>
  async (u: URL): Promise<ProbeResult> => ({ finalUrl: u.href, status: 200, contentType: 'video/mp4', contentLength: 5_000_000, ...over });

const analyzerWith = (probe: (u: URL) => Promise<ProbeResult>) => createAnalyzer([createDirectMediaProvider(probe)]);
const code = async (p: Promise<unknown>) => {
  try {
    await p;
  } catch (e) {
    return e instanceof AnalyzeError ? e.code : 'other';
  }
  return 'no_error';
};

describe('analyzer', () => {
  it('returns real data for a valid media file', async () => {
    const r = await analyzerWith(ok())('https://cdn.example.com/files/My%20Clip.mp4');
    expect(r.title).toBe('My Clip.mp4');
    expect(r.thumbnail).toBeNull();
    expect(r.durationSeconds).toBeNull();
    expect(r.formats).toHaveLength(1);
    expect(r.formats[0]).toMatchObject({ container: 'mp4', sizeBytes: 5_000_000 });
  });
  it('reports unknown size honestly instead of guessing', async () => {
    const r = await analyzerWith(ok({ contentLength: null }))('https://cdn.example.com/a.mp4');
    expect(r.formats[0].sizeBytes).toBeNull();
    expect(r.notes.length).toBeGreaterThan(0);
  });
  it('rejects empty and invalid input', async () => {
    const a = analyzerWith(ok());
    expect(await code(a(''))).toBe('invalid_url');
    expect(await code(a('nope'))).toBe('invalid_url');
    expect(await code(a(undefined))).toBe('invalid_url');
    expect(await code(a('http://example.com/a.mp4'))).toBe('invalid_url');
    expect(await code(a('https://127.0.0.1/a.mp4'))).toBe('invalid_url');
  });
  it('explains unsupported platforms without probing them', async () => {
    let probed = false;
    const a = analyzerWith(async (u) => {
      probed = true;
      return ok()(u);
    });
    for (const u of ['https://www.youtube.com/watch?v=abc', 'https://youtu.be/abc', 'https://soundcloud.com/x/y', 'https://www.tiktok.com/@a/video/1']) {
      expect(await code(a(u)), u).toBe('platform_not_supported');
    }
    expect(probed).toBe(false);
  });
  it('rejects web pages, manifests and oversized files', async () => {
    expect(await code(analyzerWith(ok({ contentType: 'text/html' }))('https://example.com/page'))).toBe('not_media');
    expect(await code(analyzerWith(ok({ contentType: 'application/vnd.apple.mpegurl' }))('https://example.com/a'))).toBe('streaming_manifest');
    expect(await code(analyzerWith(ok({ contentLength: 50 * 1024 ** 3 }))('https://example.com/a.mp4'))).toBe('too_large');
  });
  it('maps source failures to useful errors', async () => {
    expect(await code(analyzerWith(ok({ status: 404 }))('https://example.com/a.mp4'))).toBe('source_gone');
    expect(await code(analyzerWith(ok({ status: 403 }))('https://example.com/a.mp4'))).toBe('access_denied');
    expect(await code(analyzerWith(ok({ status: 503 }))('https://example.com/a.mp4'))).toBe('source_unavailable');
    const failing = (c: ConstructorParameters<typeof ProbeError>[0]) => async (): Promise<ProbeResult> => {
      throw new ProbeError(c);
    };
    expect(await code(analyzerWith(failing('timeout'))('https://example.com/a.mp4'))).toBe('source_timeout');
    expect(await code(analyzerWith(failing('blocked_target'))('https://example.com/a.mp4'))).toBe('blocked_target');
    expect(await code(analyzerWith(failing('network'))('https://example.com/a.mp4'))).toBe('source_unavailable');
  });
});
