import { describe, expect, it } from 'vitest';
import { validateMediaUrl } from '../shared/url';
import { aspectRatio, estimateFileSizeBytes, formatBytes, scaledHeight, toSeconds, videoBitrateForSize } from '../shared/calc';

describe('validateMediaUrl', () => {
  it('rejects empty input', () => {
    expect(validateMediaUrl('   ')).toMatchObject({ ok: false });
  });
  it('rejects malformed URLs', () => {
    expect(validateMediaUrl('not a url')).toMatchObject({ ok: false });
  });
  it('rejects non-https schemes', () => {
    for (const u of ['http://example.com/a.mp4', 'ftp://example.com/a.mp4', 'file:///etc/passwd', 'javascript:alert(1)']) {
      expect(validateMediaUrl(u).ok).toBe(false);
    }
  });
  it('rejects credentials, odd ports, IP literals, and local hostnames', () => {
    for (const u of [
      'https://user:pw@example.com/a.mp4',
      'https://example.com:8443/a.mp4',
      'https://127.0.0.1/a.mp4',
      'https://[::1]/a.mp4',
      'https://169.254.169.254/latest/meta-data',
      'https://localhost/a.mp4',
      'https://intranet/a.mp4',
      'https://printer.local/a.mp4',
    ]) {
      expect(validateMediaUrl(u).ok, u).toBe(false);
    }
  });
  it('accepts a normal https media URL', () => {
    const r = validateMediaUrl('https://example.com/video.mp4');
    expect(r.ok).toBe(true);
  });
});

describe('calculators', () => {
  it('estimates file size', () => {
    // 10 minutes at 5000 + 128 kbps
    const bytes = estimateFileSizeBytes(5000, 128, toSeconds(0, 10, 0));
    expect(Math.round(bytes / 1e6)).toBe(385);
  });
  it('computes bitrate for a target size', () => {
    const kbps = videoBitrateForSize(100e6, 600, 128)!;
    expect(Math.round(kbps)).toBe(1205);
  });
  it('returns null when the target is impossible', () => {
    expect(videoBitrateForSize(1e6, 600, 128)).toBeNull();
    expect(videoBitrateForSize(100e6, 0, 128)).toBeNull();
  });
  it('computes aspect ratio and scaled height', () => {
    expect(aspectRatio(1920, 1080)).toMatchObject({ w: 16, h: 9 });
    expect(aspectRatio(0, 10)).toBeNull();
    expect(scaledHeight(1920, 1080, 1280)).toBe(720);
    expect(scaledHeight(1000, 333, 500)! % 2).toBe(0);
  });
  it('formats bytes', () => {
    expect(formatBytes(1500)).toBe('1.50 KB');
    expect(formatBytes(NaN)).toBe('—');
  });
});
