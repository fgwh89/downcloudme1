import { describe, expect, it } from 'vitest';
import { createAnalyzeHandler, createRateLimiter } from '../server/src/handler';
import { createAnalyzer } from '../server/src/registry';
import { createDirectMediaProvider } from '../server/src/providers/direct';

const analyzer = createAnalyzer([
  createDirectMediaProvider(async (u) => ({ finalUrl: u.href, status: 200, contentType: 'audio/mpeg', contentLength: 1234 })),
]);

const post = (body: unknown, headers: Record<string, string> = {}, raw = false) =>
  new Request('https://site.example/api/analyze', {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...headers },
    body: raw ? (body as string) : JSON.stringify(body),
  });

describe('analyze handler', () => {
  const handle = createAnalyzeHandler({ analyzer, rateLimitMax: 100, allowedOrigins: [] });

  it('returns 200 with a real result for a valid link', async () => {
    const res = await handle(post({ url: 'https://example.com/song.mp3' }), '1.1.1.1');
    expect(res.status).toBe(200);
    expect(res.headers.get('cache-control')).toBe('no-store');
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.result.formats[0]).toMatchObject({ container: 'mp3', sizeBytes: 1234 });
  });

  it('rejects non-POST methods', async () => {
    const res = await handle(new Request('https://site.example/api/analyze'), '1.1.1.1');
    expect(res.status).toBe(405);
  });

  it('returns 400 for malformed JSON without leaking internals', async () => {
    const res = await handle(post('{bad', {}, true), '1.1.1.1');
    expect(res.status).toBe(400);
    expect(await res.text()).not.toMatch(/SyntaxError|node_modules|\.ts:/);
  });

  it('returns 400 for oversized bodies', async () => {
    const res = await handle(post({ url: 'https://example.com/' + 'a'.repeat(5000) }), '1.1.1.1');
    expect(res.status).toBe(400);
  });

  it('returns 400 for empty, missing and insecure URLs', async () => {
    for (const body of [{ url: '' }, {}, { url: 'http://example.com/a.mp4' }, { url: 'https://127.0.0.1/a.mp4' }, null]) {
      const res = await handle(post(body), '1.1.1.1');
      expect(res.status, JSON.stringify(body)).toBe(400);
      expect((await res.json()).error.code).toBe('invalid_url');
    }
  });

  it('returns 422 with an official link for unsupported platforms', async () => {
    const res = await handle(post({ url: 'https://www.youtube.com/watch?v=abc' }), '1.1.1.1');
    expect(res.status).toBe(422);
    const body = await res.json();
    expect(body.error.code).toBe('platform_not_supported');
    expect(body.error.officialUrl).toMatch(/^https:\/\//);
  });

  it('returns a generic 500 when something unexpected throws', async () => {
    const boom = createAnalyzeHandler({ analyzer: async () => { throw new Error('secret /srv/path'); }, allowedOrigins: [] });
    const res = await boom(post({ url: 'https://example.com/a.mp4' }), '1.1.1.1');
    expect(res.status).toBe(500);
    expect(await res.text()).not.toMatch(/secret|\/srv/);
  });

  it('enforces the origin allowlist when configured', async () => {
    const strict = createAnalyzeHandler({ analyzer, allowedOrigins: ['https://site.example'] });
    expect((await strict(post({ url: 'https://example.com/a.mp3' }, { origin: 'https://evil.example' }), 'a')).status).toBe(403);
    expect((await strict(post({ url: 'https://example.com/a.mp3' }, { origin: 'https://site.example' }), 'a')).status).toBe(200);
  });

  it('rate limits per client IP', async () => {
    const limited = createAnalyzeHandler({ analyzer, rateLimitMax: 3, allowedOrigins: [] });
    const statuses: number[] = [];
    for (let i = 0; i < 5; i++) statuses.push((await limited(post({ url: 'https://example.com/a.mp3' }), '9.9.9.9')).status);
    expect(statuses).toEqual([200, 200, 200, 429, 429]);
    const res = await limited(post({ url: 'https://example.com/a.mp3' }), '9.9.9.9');
    expect(res.headers.get('retry-after')).toBeTruthy();
    // A different client is unaffected.
    expect((await limited(post({ url: 'https://example.com/a.mp3' }), '8.8.8.8')).status).toBe(200);
  });
});

describe('createRateLimiter', () => {
  it('resets after the window', () => {
    let t = 0;
    const check = createRateLimiter(1, 1000, () => t);
    expect(check('k').allowed).toBe(true);
    expect(check('k').allowed).toBe(false);
    t = 1001;
    expect(check('k').allowed).toBe(true);
  });
});
