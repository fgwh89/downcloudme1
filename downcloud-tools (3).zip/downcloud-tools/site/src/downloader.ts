import { validateMediaUrl } from '../../shared/url';
import { formatBytes } from '../../shared/calc';

const API_BASE = (import.meta.env.VITE_API_BASE ?? '').replace(/\/$/, '');
const REQUEST_TIMEOUT_MS = 20_000;

type Format = { id: string; label: string; container: string; sizeBytes: number | null; url: string };
type Result = {
  providerName: string;
  title: string;
  source: string;
  thumbnail: string | null;
  durationSeconds: number | null;
  formats: Format[];
  notes: string[];
};
type ApiError = { code: string; message: string; officialUrl?: string };

function el<K extends keyof HTMLElementTagNameMap>(tag: K, props: Record<string, string> = {}, children: (Node | string)[] = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) node.setAttribute(k, v);
  for (const c of children) node.append(c);
  return node;
}

const isHttps = (u: string) => {
  try {
    return new URL(u).protocol === 'https:';
  } catch {
    return false;
  }
};

export function initDownloader() {
  const form = document.getElementById('dl-form') as HTMLFormElement | null;
  if (!form) return;
  const input = document.getElementById('dl-url') as HTMLInputElement;
  const submit = document.getElementById('dl-submit') as HTMLButtonElement;
  const clear = document.getElementById('dl-clear') as HTMLButtonElement;
  const paste = document.getElementById('dl-paste') as HTMLButtonElement;
  const errorBox = document.getElementById('dl-error') as HTMLElement;
  const status = document.getElementById('dl-status') as HTMLElement;
  const resultBox = document.getElementById('dl-result') as HTMLElement;

  const showError = (message: string, officialUrl?: string) => {
    errorBox.replaceChildren(message);
    if (officialUrl && isHttps(officialUrl)) {
      errorBox.append(' ', el('a', { href: officialUrl, rel: 'noopener noreferrer', target: '_blank' }, ['Visit the official site']), '.');
    }
    errorBox.hidden = false;
  };
  const reset = () => {
    errorBox.hidden = true;
    errorBox.replaceChildren();
    status.textContent = '';
    resultBox.hidden = true;
    resultBox.replaceChildren();
  };

  if (navigator.clipboard && typeof navigator.clipboard.readText === 'function') {
    paste.hidden = false;
    paste.addEventListener('click', async () => {
      try {
        input.value = (await navigator.clipboard.readText()).trim();
        input.focus();
      } catch {
        showError('Your browser blocked clipboard access. Paste the link manually with Ctrl+V or long-press.');
      }
    });
  }

  clear.addEventListener('click', () => {
    input.value = '';
    reset();
    input.focus();
  });

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    reset();

    const check = validateMediaUrl(input.value);
    if (!check.ok) return showError(check.error);

    submit.disabled = true;
    status.textContent = 'Checking the link…';
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), REQUEST_TIMEOUT_MS);

    try {
      const res = await fetch(`${API_BASE}/api/analyze`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ url: check.url.href }),
        signal: ctrl.signal,
      });
      let data: { ok: boolean; result?: Result; error?: ApiError } | null = null;
      try {
        data = await res.json();
      } catch {
        /* non-JSON response (for example a hosting error page) */
      }
      status.textContent = '';
      if (data?.ok && data.result) return render(data.result);
      if (res.status === 404 && !data) return showError('The analysis service is not available. If you are the site owner, check that the Netlify function deployed (see the README).');
      showError(data?.error?.message ?? 'The analysis service returned an unexpected response.', data?.error?.officialUrl);
    } catch (e) {
      status.textContent = '';
      showError(
        e instanceof DOMException && e.name === 'AbortError'
          ? 'The analysis service took too long to respond. Please try again.'
          : 'Could not reach the analysis service. Check your connection and try again.',
      );
    } finally {
      clearTimeout(timer);
      submit.disabled = false;
    }
  });

  function render(r: Result) {
    const meta: [string, string][] = [
      ['Source', r.source],
      ['Type', r.providerName],
    ];
    if (r.durationSeconds !== null) meta.push(['Duration', `${Math.round(r.durationSeconds)} s`]);

    const card = el('div', { class: 'result-card' }, [
      el('h2', { class: 'result-title' }, [r.title]),
      el('dl', { class: 'meta' }, meta.flatMap(([k, v]) => [el('dt', {}, [k]), el('dd', {}, [v])])),
    ]);

    if (r.thumbnail && isHttps(r.thumbnail)) {
      card.prepend(el('img', { src: r.thumbnail, alt: `Thumbnail for ${r.title}`, class: 'thumb', loading: 'lazy', referrerpolicy: 'no-referrer' }));
    }

    const list = el('ul', { class: 'formats' });
    for (const f of r.formats) {
      if (!isHttps(f.url)) continue; // never render a link we cannot verify as https
      const size = f.sizeBytes !== null ? formatBytes(f.sizeBytes) : 'size not reported';
      list.append(
        el('li', {}, [
          el('span', {}, [`${f.label} · ${size}`]),
          el('a', { class: 'btn primary', href: f.url, download: '', rel: 'noopener noreferrer', target: '_blank' }, ['Download']),
        ]),
      );
    }
    card.append(list);
    card.append(el('p', { class: 'fine-print' }, ['The Download button opens the original file on the host’s own server. Your browser handles the transfer, so if the host blocks or has removed the file, the browser will show that error.']));
    for (const n of r.notes) card.append(el('p', { class: 'fine-print' }, [n]));

    resultBox.replaceChildren(card);
    resultBox.hidden = false;
  }
}
