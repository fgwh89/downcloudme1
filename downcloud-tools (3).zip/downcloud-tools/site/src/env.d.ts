/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Base URL of the analysis backend, e.g. https://api.example.com (no trailing slash). Empty = same origin / dev proxy. */
  readonly VITE_API_BASE?: string;
}
