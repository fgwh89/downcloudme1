import {
  aspectRatio,
  estimateFileSizeBytes,
  formatBytes,
  formatDuration,
  scaledHeight,
  toSeconds,
  videoBitrateForSize,
} from '../../shared/calc';

function num(form: HTMLFormElement, name: string): number {
  const v = (form.elements.namedItem(name) as HTMLInputElement | HTMLSelectElement | null)?.value ?? '';
  return v.trim() === '' ? NaN : Number(v);
}
const num0 = (form: HTMLFormElement, name: string) => {
  const n = num(form, name);
  return Number.isNaN(n) ? 0 : n;
};

function bind(id: string, compute: (form: HTMLFormElement) => string) {
  const form = document.getElementById(id) as HTMLFormElement | null;
  if (!form) return;
  const out = form.querySelector<HTMLElement>('[data-out]');
  const run = () => {
    if (out) out.textContent = compute(form);
  };
  form.addEventListener('input', run);
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    run();
  });
  run();
}

export function initCalculators() {
  bind('calc-size', (f) => {
    const seconds = toSeconds(num0(f, 'h'), num0(f, 'm'), num0(f, 's'));
    const v = num(f, 'video');
    const a = num0(f, 'audio');
    if (!(seconds > 0)) return 'Enter a duration greater than zero.';
    if (!(v >= 0)) return 'Enter a video bitrate in kbps.';
    const bytes = estimateFileSizeBytes(v, a, seconds);
    return `Estimated size: ${formatBytes(bytes)} (${(bytes / 1024 ** 2).toFixed(1)} MiB) for ${formatDuration(seconds)} at ${v + a} kbps total. Real files vary with container overhead and variable bitrate.`;
  });

  bind('calc-bitrate', (f) => {
    const seconds = toSeconds(num0(f, 'h'), num0(f, 'm'), num0(f, 's'));
    const size = num(f, 'size');
    const unit = (f.elements.namedItem('unit') as HTMLSelectElement).value;
    const audio = num0(f, 'audio');
    if (!(seconds > 0)) return 'Enter a duration greater than zero.';
    if (!(size > 0)) return 'Enter a target file size.';
    const bytes = size * (unit === 'GB' ? 1e9 : 1e6);
    const video = videoBitrateForSize(bytes, seconds, audio);
    if (video === null) return 'The target size is too small for that duration and audio bitrate. Increase the size or lower the audio bitrate.';
    return `Video bitrate to aim for: about ${Math.floor(video)} kbps (plus ${audio} kbps audio). Leave a few percent of headroom for container overhead.`;
  });

  bind('calc-aspect', (f) => {
    const w = num(f, 'w');
    const h = num(f, 'h');
    const r = aspectRatio(w, h);
    if (!r) return 'Enter a width and height greater than zero.';
    let text = `Aspect ratio: ${r.w}:${r.h} (${r.decimal.toFixed(3)}:1).`;
    const nw = num(f, 'newWidth');
    if (nw > 0) {
      const nh = scaledHeight(w, h, nw);
      if (nh) text += ` At a width of ${Math.round(nw)} px, the matching height is ${nh} px (rounded to an even number).`;
    }
    return text;
  });
}
