import { defineConfig } from 'vite';
import { readdirSync, statSync } from 'node:fs';
import { join, resolve } from 'node:path';

const root = resolve(__dirname, 'site');

// Every generated page (site/**/index.html and site/404.html) becomes a build entry.
function collectHtml(dir: string, out: Record<string, string> = {}): Record<string, string> {
  for (const name of readdirSync(dir)) {
    if (name === 'src' || name === 'node_modules') continue;
    const full = join(dir, name);
    if (statSync(full).isDirectory()) collectHtml(full, out);
    else if (name.endsWith('.html')) out[full.slice(root.length + 1).replace(/[\\/.]/g, '_')] = full;
  }
  return out;
}

export default defineConfig({
  root,
  publicDir: resolve(__dirname, 'public'),
  build: {
    outDir: resolve(__dirname, 'dist'),
    emptyOutDir: true,
    rollupOptions: { input: collectHtml(root) },
  },
  server: {
    fs: { allow: [resolve(__dirname)] },
  },
  test: {
    root: __dirname,
    include: ['tests/**/*.test.ts'],
  },
});
