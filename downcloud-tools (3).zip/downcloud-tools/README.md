# DownCloud Tools

A free, privacy-minded website for checking links to audio/video files and working with video numbers (file size, bitrate, aspect ratio). It deploys to **Netlify as a single project**: static pages plus two Netlify Functions. There is no separate backend to host.

## What it actually does

| Feature | Status |
|---|---|
| Analyze a **direct HTTPS link to a media file** (type and size from the host's headers) and offer the original file for download | Implemented (Netlify Function) |
| Explain **unsupported platforms** (YouTube, SoundCloud, TikTok, Instagram, Facebook, X, Vimeo, Spotify, Netflix, Twitch) with a link to the official site | Implemented |
| File size, bitrate and aspect ratio calculators (browser only) | Implemented |
| Format guide, resolution guide, blog, legal pages, FAQ | Implemented |
| Extraction from YouTube, SoundCloud, TikTok and similar | **Deliberately not implemented** |

Those platforms allow downloads only through their own features; extracting from them means bypassing access controls. The site says so plainly instead of faking results. New sources can be added as adapters in `server/src/providers/`, but only add one if there is an authorized way to get the media, and test it first.

No fabricated titles, thumbnails, durations, resolutions or sizes: for plain files only the filename (from the URL), host, file type and server-reported size are shown. The Download button points at the host's own URL; the function never proxies or stores the file.

## Project layout

```
netlify/functions/   analyze.mts (POST /api/analyze), health.mts (GET /api/health)
server/src/          handler.ts (request handling, rate limit), registry.ts, ssrf.ts, providers/
shared/              URL validation + calculator math (browser and function)
content/             layout.mjs (header/footer/SEO/JSON-LD), pages.mjs (all page content)
scripts/generate.mjs writes site/**/index.html, public/sitemap.xml, public/robots.txt
site/src/            main.ts (theme, nav), downloader.ts, calculators.ts, styles.css
tests/               Vitest tests
netlify.toml         build, functions and security headers
```

## Deploy to Netlify

1. Push this folder to a GitHub, GitLab or Bitbucket repo.
2. In Netlify: **Add new site > Import an existing project**, pick the repo. Settings are read from `netlify.toml` (build command `npm run build`, publish directory `dist`, functions in `netlify/functions`). Leave them as detected.
3. Under **Site configuration > Environment variables**, set `CONTACT_EMAIL` to your real address. `SITE_URL` is optional: if empty, the build uses the URL Netlify provides (your `*.netlify.app` address or your primary custom domain). See `.env.example` for the optional function settings.
4. Deploy. Then check:
   - `https://YOUR-SITE/api/health` returns `{"ok":true}`
   - the homepage analyzer returns a clear message for a YouTube link and works for a real direct `.mp4` link.
5. **Custom domain:** Domain management > Add a domain. After the domain is primary, trigger a redeploy so canonical links, sitemap.xml and robots.txt use it (or set `SITE_URL`).

The frontend calls `/api/analyze` on the same origin, so there is no CORS setup and no `VITE_API_BASE` is needed.

### Local development

```bash
npm install
npm run dev:netlify    # runs `netlify dev`: site plus functions at http://localhost:8888
```

`npm run dev` alone serves only the static pages (the analyzer will show "service not available" because the functions are not running). `npm run dev:netlify` uses the Netlify CLI; install it globally with `npm i -g netlify-cli` if the command is not found. Other scripts: `npm run build`, `npm run preview`, `npm run typecheck`, `npm test`.

## API

- `GET /api/health` returns `{ "ok": true }`.
- `POST /api/analyze` with body `{ "url": "https://…" }`.
  - 200: `{ ok: true, result: { provider, providerName, title, source, thumbnail, durationSeconds, formats[], notes[] } }`
  - Errors: `{ ok: false, error: { code, message, officialUrl? } }`. Codes: `invalid_url` (400), `bad_request` (400), `blocked_target` (400), `origin_not_allowed` (403), `access_denied` (403), `source_gone` (404), `method_not_allowed` (405), `too_large` (413), `platform_not_supported` / `not_media` / `streaming_manifest` (422), `rate_limited` (429), `server_error` (500), `source_unavailable` (502), `source_timeout` (504).

## Security controls

- Client and server both validate: https only, no credentials, port 443 only, no IP literals, no local-looking hostnames.
- **SSRF:** DNS is resolved inside the socket's `lookup` hook and every address must be globally routable, so private, loopback, link-local, CGNAT and metadata addresses are refused at connect time (also defeats DNS rebinding). Redirects are followed manually (max 3) and each hop is re-validated.
- Only headers are read (HEAD, or a 1-byte ranged GET); bodies are never read. Each request has a 4 s timeout and the whole check an 8 s budget, to stay under Netlify's default 10 s function limit.
- 4 KB body limit, optional origin allowlist, `no-store` and `nosniff` headers, generic error messages, and logs never contain the submitted URL.
- No shell commands, no temp files, no stored URLs.
- **Rate limit caveat:** the limiter (default 20 requests/minute per IP) lives in memory, and Netlify may run several function instances, each with its own counter. It slows bursts but is not a hard global cap. For stronger protection, add a Netlify rate-limiting rule or firewall setting from your Netlify dashboard (availability depends on your plan; check Netlify's current docs), and keep an eye on function usage in your plan.
- "Direct media" links can point at any public host, so there is no domain allowlist for that provider; the SSRF layer is the control. Add a host allowlist in `server/src/providers/direct.ts` if you want it stricter.

## Testing: what has actually been run

Run: `npm run typecheck` (clean), `npm test` (37 tests passing), `npm run build` (21 pages), the function bundled with esbuild (as Netlify does), and an earlier check that all 635 internal links in the built site resolve with one H1 per page.

Covered by automated tests: valid, invalid and empty URLs, unsupported platform, simulated expired (404), unavailable and timed-out sources, simulated oversized file, URL security validation, SSRF address classification, origin allowlist, malformed and oversized request bodies, generic 500s, and rate limiting.

**Not run, so not claimed:** the function against real external hosts (this environment has no outbound network, so the live check and DNS-level SSRF blocking are untested end to end), a real Netlify deployment, mobile/desktop visual checks, theme persistence and keyboard navigation in a browser. Test those on your deploy preview before launch.

## Before you go live

- Set `CONTACT_EMAIL`. Until then pages show `contact@your-domain.example`.
- Have the legal pages reviewed for your jurisdiction. They describe the site as shipped (no analytics, no ads, theme in local storage) and must be updated if you change that.
- No Open Graph image is included; add one under `public/` and reference it in `content/layout.mjs` for rich previews.

## Google AdSense

Hidden placeholders (`.ad-slot[hidden]`) sit at the bottom of content pages, away from the tool. They are inactive: no publisher ID and no ad code. Once Google gives you official code, paste it into the slot in `content/layout.mjs`, remove `hidden`, add consent where the law requires it, and update the privacy and cookie policies. Approval is decided solely by Google and cannot be guaranteed; sites centered on downloading media can face extra scrutiny.

## SEO notes

Unique title, description, H1 and canonical on every page; breadcrumbs with BreadcrumbList JSON-LD; WebSite, WebApplication, BlogPosting and FAQPage structured data where appropriate; sitemap and robots generated at build time. Nothing here promises rankings.
