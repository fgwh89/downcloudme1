import { mkdirSync, writeFileSync, rmSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { pages } from '../content/pages.mjs';
import { renderPage, renderSitemap, renderRobots } from '../content/layout.mjs';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const siteDir = join(root, 'site');

// Remove previously generated pages (keep site/src).
for (const entry of ['index.html', '404.html', ...new Set(pages.map((p) => p.path.split('/')[1]).filter(Boolean))]) {
  const target = join(siteDir, entry);
  if (existsSync(target)) rmSync(target, { recursive: true, force: true });
}

for (const page of pages) {
  const file = page.path.endsWith('.html') ? join(siteDir, page.path) : join(siteDir, page.path, 'index.html');
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, renderPage(page));
}

mkdirSync(join(root, 'public'), { recursive: true });
writeFileSync(join(root, 'public', 'sitemap.xml'), renderSitemap(pages));
writeFileSync(join(root, 'public', 'robots.txt'), renderRobots());
console.log(`Generated ${pages.length} pages, sitemap.xml and robots.txt`);
