// Shared layout, SEO metadata and structured data for every generated page.

export const SITE = {
  name: 'DownCloud Tools',
  // SITE_URL wins; otherwise use the primary URL Netlify provides at build time (URL); otherwise a placeholder.
  url: (process.env.SITE_URL || process.env.URL || 'https://your-domain.example').replace(/\/$/, ''),
  contactEmail: process.env.CONTACT_EMAIL ?? 'contact@your-domain.example',
  tagline: 'Free online video downloader and media tools',
  today: new Date().toISOString().slice(0, 10),
};

export const NAV = [
  ['/', 'Home'],
  ['/video-downloader/', 'Video Downloader'],
  ['/supported-platforms/', 'Supported Platforms'],
  ['/how-to-download/', 'How It Works'],
  ['/faq/', 'FAQ'],
  ['/blog/', 'Blog'],
  ['/about/', 'About Us'],
  ['/contact/', 'Contact'],
];

const FOOTER_TOOLS = [
  ['/video-file-size-calculator/', 'Video File Size Calculator'],
  ['/video-bitrate-calculator/', 'Video Bitrate Calculator'],
  ['/video-aspect-ratio-calculator/', 'Aspect Ratio Calculator'],
  ['/video-format-guide/', 'Video Format Guide'],
  ['/video-resolution-guide/', 'Video Resolution Guide'],
];

const FOOTER_LEGAL = [
  ['/privacy-policy/', 'Privacy Policy'],
  ['/terms-and-conditions/', 'Terms and Conditions'],
  ['/disclaimer/', 'Disclaimer'],
  ['/copyright-policy/', 'Copyright Policy'],
  ['/cookie-policy/', 'Cookie Policy'],
];

export const esc = (s) =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const LOGO = `<svg class="logo-mark" viewBox="0 0 32 32" width="32" height="32" role="img" aria-label="DownCloud Tools logo: a cloud with a download arrow"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7c5cff"/><stop offset="1" stop-color="#3b82f6"/></linearGradient></defs><path d="M9 25a6 6 0 0 1-.9-11.9A8 8 0 0 1 23.4 11 6.5 6.5 0 0 1 23 25z" fill="url(#lg)"/><path d="M16 12.5v8m-3.5-3.5 3.5 3.5 3.5-3.5" stroke="#fff" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

export const DOWNLOADER_HTML = `
<section class="tool-card" aria-label="Media URL analyzer">
  <form id="dl-form" novalidate>
    <label for="dl-url" class="sr-only">Media URL</label>
    <div class="url-row">
      <input id="dl-url" name="url" type="url" inputmode="url" autocomplete="off" spellcheck="false" placeholder="Paste your supported media URL here..." required>
      <button type="button" id="dl-paste" class="btn ghost" hidden>Paste</button>
      <button type="button" id="dl-clear" class="btn ghost">Clear</button>
      <button type="submit" id="dl-submit" class="btn primary">Analyze URL</button>
    </div>
    <p id="dl-error" class="form-error" role="alert" hidden></p>
  </form>
  <div id="dl-status" class="status" aria-live="polite"></div>
  <div id="dl-result" hidden></div>
  <p class="fine-print">Your link is sent to our server so it can check the file's headers. See the <a href="/privacy-policy/">privacy policy</a>. Download only content you own, have permission to save, or are legally allowed to download.</p>
</section>`;

const adSlot = (id) =>
  `<div class="ad-slot" data-ad-slot="${id}" hidden aria-label="Advertisement placeholder (inactive)"><!-- Paste official ad code here after Google approves the site, then remove the hidden attribute. --></div>`;

function breadcrumbs(page) {
  if (page.path === '/') return { html: '', trail: [] };
  const trail = [['/', 'Home']];
  if (page.parent) trail.push(page.parent);
  trail.push([page.path, page.h1]);
  const html = `<nav class="crumbs" aria-label="Breadcrumb"><ol>${trail
    .map(([href, label], i) =>
      i === trail.length - 1 ? `<li aria-current="page">${esc(label)}</li>` : `<li><a href="${href}">${esc(label)}</a></li>`)
    .join('')}</ol></nav>`;
  return { html, trail };
}

function jsonLd(page, trail) {
  const url = SITE.url + page.path;
  const graph = [];
  if (page.path === '/') {
    graph.push({ '@type': 'WebSite', name: SITE.name, url: SITE.url + '/', description: SITE.tagline, inLanguage: 'en' });
  }
  if (page.schema === 'webapp') {
    graph.push({
      '@type': 'WebApplication',
      name: 'DownCloud Tools Media URL Analyzer',
      url,
      applicationCategory: 'MultimediaApplication',
      operatingSystem: 'Any (web browser)',
      description: page.description,
      offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
    });
  }
  if (page.schema === 'article') {
    graph.push({
      '@type': 'BlogPosting',
      headline: page.h1,
      description: page.description,
      datePublished: page.date ?? SITE.today,
      dateModified: page.date ?? SITE.today,
      mainEntityOfPage: url,
      author: { '@type': 'Organization', name: SITE.name },
      publisher: { '@type': 'Organization', name: SITE.name },
    });
  }
  if (page.faq) {
    graph.push({
      '@type': 'FAQPage',
      mainEntity: page.faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a.replace(/<[^>]+>/g, '') } })),
    });
  }
  if (trail.length) {
    graph.push({
      '@type': 'BreadcrumbList',
      itemListElement: trail.map(([href, label], i) => ({ '@type': 'ListItem', position: i + 1, name: label, item: SITE.url + href })),
    });
  }
  if (!graph.length) return '';
  return `<script type="application/ld+json">${JSON.stringify({ '@context': 'https://schema.org', '@graph': graph })}</script>`;
}

export function renderPage(page) {
  const { html: crumbHtml, trail } = breadcrumbs(page);
  const url = SITE.url + page.path;
  const title = page.path === '/' ? page.title : `${page.title} | ${SITE.name}`;
  const nav = NAV.map(([href, label]) => `<li><a href="${href}"${href === page.path ? ' aria-current="page"' : ''}>${label}</a></li>`).join('');
  const list = (items) => items.map(([h, l]) => `<li><a href="${h}">${l}</a></li>`).join('');
  const robots = page.noindex ? '<meta name="robots" content="noindex">' : '';

  return `<!doctype html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)}</title>
<meta name="description" content="${esc(page.description)}">
${robots}
<link rel="canonical" href="${url}">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<meta name="theme-color" content="#0b1224">
<meta property="og:type" content="${page.schema === 'article' ? 'article' : 'website'}">
<meta property="og:site_name" content="${SITE.name}">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(page.description)}">
<meta property="og:url" content="${url}">
<meta name="twitter:card" content="summary">
<script>try{var t=localStorage.getItem('theme');document.documentElement.dataset.theme=(t==='light'||t==='dark')?t:'dark'}catch(e){}</script>
${jsonLd(page, trail)}
<script type="module" src="/src/main.ts"></script>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<header class="site-header">
  <div class="wrap header-row">
    <a class="brand" href="/">${LOGO}<span>DownCloud Tools</span></a>
    <button id="nav-toggle" class="icon-btn nav-toggle" aria-expanded="false" aria-controls="site-nav" aria-label="Open menu">
      <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/></svg>
    </button>
    <nav id="site-nav" class="site-nav" aria-label="Primary"><ul>${nav}</ul></nav>
    <button id="theme-toggle" class="icon-btn" aria-label="Switch to light mode" aria-pressed="false" title="Toggle dark / light mode">
      <svg class="i-moon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z" fill="currentColor"/></svg>
      <svg class="i-sun" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><circle cx="12" cy="12" r="4" fill="currentColor"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
    </button>
  </div>
</header>
<main id="main">
${page.hero ?? ''}
<div class="wrap content">
${crumbHtml}
${page.hero ? '' : `<h1>${esc(page.h1)}</h1>`}
${page.lead && !page.hero ? `<p class="lead">${page.lead}</p>` : ''}
${page.body}
${page.noAds ? '' : adSlot('content-bottom')}
</div>
</main>
<footer class="site-footer">
  <div class="wrap footer-grid">
    <div>
      <a class="brand" href="/">${LOGO}<span>DownCloud Tools</span></a>
      <p class="muted">Independent tools for checking and saving media you have the right to download. Not affiliated with any media platform.</p>
    </div>
    <div><h2 class="footer-h">Tools</h2><ul>${list(FOOTER_TOOLS)}</ul></div>
    <div><h2 class="footer-h">Company</h2><ul>${list([['/about/', 'About Us'], ['/contact/', 'Contact'], ['/faq/', 'FAQ'], ['/blog/', 'Blog'], ['/supported-platforms/', 'Supported Platforms']])}</ul></div>
    <div><h2 class="footer-h">Legal</h2><ul>${list(FOOTER_LEGAL)}</ul></div>
  </div>
  <div class="wrap footer-base"><p>&copy; ${new Date().getFullYear()} DownCloud Tools. Use these tools only with content you have permission to download.</p></div>
</footer>
</body>
</html>
`;
}

export function renderSitemap(pages) {
  const urls = pages.filter((p) => !p.noindex).map((p) => `  <url><loc>${SITE.url}${p.path}</loc><lastmod>${SITE.today}</lastmod></url>`).join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}

export function renderRobots() {
  return `User-agent: *\nAllow: /\n\nSitemap: ${SITE.url}/sitemap.xml\n`;
}
