import { DOWNLOADER_HTML, SITE } from './layout.mjs';

const UPDATED = SITE.today;
const mail = `<a href="mailto:${SITE.contactEmail}">${SITE.contactEmail}</a>`;

const hero = `
<section class="hero">
  <div class="wrap">
    <h1>Free Online Video Downloader</h1>
    <p class="lead">Paste a supported media URL to check available download options. Download only content you own, have permission to save, or are otherwise legally allowed to download.</p>
    ${DOWNLOADER_HTML}
    <p class="fine-print">Currently supported: direct links to audio or video files (https). Platform pages such as YouTube are <a href="/supported-platforms/">not supported</a> &mdash; see why.</p>
  </div>
</section>`;

const toolCard = (href, title, text) =>
  `<div class="card"><h3>${title}</h3><p>${text}</p><a class="card-link" href="${href}">Open ${title.toLowerCase()}</a></div>`;

const timeFields = `
<div class="row">
  <div class="field"><label for="h">Hours</label><input id="h" name="h" type="number" min="0" step="1" value="0" inputmode="numeric"></div>
  <div class="field"><label for="m">Minutes</label><input id="m" name="m" type="number" min="0" step="1" value="10" inputmode="numeric"></div>
  <div class="field"><label for="s">Seconds</label><input id="s" name="s" type="number" min="0" step="1" value="0" inputmode="numeric"></div>
</div>`;

const faq = [
  ['What does DownCloud Tools do?', 'It checks a link to an audio or video file on a public HTTPS website, reports what the server says about it (file type and size), and gives you a button that opens the original file so your browser can download it. It also offers calculators and guides for video files that run entirely in your browser.'],
  ['Which sites are supported?', 'Direct links to media files (for example a link ending in .mp4 or .mp3, served over HTTPS) are supported. Video and music platforms such as YouTube, SoundCloud, TikTok, Instagram and Spotify are intentionally not supported. See the Supported Platforms page for the reasons.'],
  ['Why can’t I download from YouTube or SoundCloud here?', 'Those services only allow downloads through their own features, and extracting files from them would mean working around their access controls. This site does not do that. Use the official download or offline options on those platforms.'],
  ['Is it free?', 'Yes. There is no account or subscription for the basic tools.'],
  ['Does the site store my links?', 'The link you submit is sent to our server to read the file’s headers. It is not saved to a database, and logs do not record the full URL. The privacy policy has the details.'],
  ['Why did my link return “not a media file”?', 'The address returned a web page or another type of file instead of audio or video. Open the link in a browser; if it shows a page with a player, the page address is not the file address.'],
  ['Why does it say the link may have expired?', 'Some hosts generate temporary signed links. Once the time limit passes, the host returns “not found” or “forbidden”. Request a fresh link from the source.'],
  ['Why is the file size missing?', 'Some servers do not report a size in their headers. We show a size only when the server provides one and never estimate it.'],
  ['Can I download playlists or streaming (m3u8) links?', 'No. Streaming playlists are lists of many small segments, not one file, so they are rejected with an explanation.'],
  ['Will you add more platforms?', 'A platform is only added if there is an authorized way to retrieve the media and the adapter has been tested. Nothing is listed as supported before that.'],
];

const faqHtml = faq.map(([q, a]) => `<details><summary>${q}</summary><p>${a}</p></details>`).join('\n');

export const pages = [
  {
    path: '/',
    title: 'Free Online Video Downloader | Direct Video Link Checker',
    h1: 'Free Online Video Downloader',
    description: 'Free online video downloader for direct media links. Paste a file URL to check its type and size, then download it. Includes free video calculators and guides.',
    schema: 'webapp',
    hero,
    body: `
<h2>How the video download tool works</h2>
<ol>
  <li><strong>Paste a link.</strong> It must be an https:// address that points straight at an audio or video file you are allowed to download.</li>
  <li><strong>Analyze it.</strong> Our server reads the file’s headers (type and size) without downloading the file itself.</li>
  <li><strong>Download.</strong> If the file checks out, the Download button opens the original file from its host.</li>
</ol>
<p>Read the <a href="/how-to-download/">full guide</a> or the <a href="/faq/">FAQ</a> if a link does not work.</p>

<h2>What is supported</h2>
<p>This is a <strong>direct video link downloader</strong>: it works with links to media files hosted on public HTTPS servers. It is <strong>not</strong> a tool for ripping videos or songs from social or streaming platforms. The <a href="/supported-platforms/">supported platforms</a> page lists exactly what works and what does not, with reasons.</p>

<h2>Free online media tools</h2>
<div class="grid">
  ${toolCard('/video-file-size-calculator/', 'Video File Size Calculator', 'Estimate how large a video will be from its bitrate and duration.')}
  ${toolCard('/video-bitrate-calculator/', 'Video Bitrate Calculator', 'Find the bitrate that fits a target file size.')}
  ${toolCard('/video-aspect-ratio-calculator/', 'Video Aspect Ratio Calculator', 'Get the ratio for any resolution and resize without distortion.')}
  ${toolCard('/video-format-guide/', 'Video Format Guide', 'MP4, WebM, MKV, MOV and audio formats compared.')}
  ${toolCard('/video-resolution-guide/', 'Video Resolution Guide', 'What 480p, 720p, 1080p and 4K mean in practice.')}
</div>

<h2>Privacy and copyright notice</h2>
<p class="notice">Links you analyze are sent to our server so it can check the file. We do not keep them. You are responsible for respecting copyright, licenses, platform terms and local law. Read the <a href="/privacy-policy/">privacy policy</a> and <a href="/copyright-policy/">copyright policy</a>.</p>`,
  },
  {
    path: '/video-downloader/',
    title: 'Online Video Downloader for Direct Media Links',
    h1: 'Online Video Downloader',
    description: 'Check a direct video or audio file link and download it. This online media downloader shows real file type and size from the host and never fakes results.',
    schema: 'webapp',
    lead: 'Paste a direct https link to an audio or video file. We read the file’s headers and, if it is valid, show a download button.',
    body: `
${DOWNLOADER_HTML}
<h2>What you will see</h2>
<p>For a valid file we show its name (taken from the link), the host, the file type, and the file size <em>when the server reports one</em>. We do not show thumbnails, durations or resolutions for plain files, because those cannot be read reliably from headers and we never invent them.</p>
<h2>When a link is rejected</h2>
<ul>
  <li><strong>Invalid or empty URL:</strong> fix the address; it must start with https://.</li>
  <li><strong>Unsupported platform:</strong> you get an explanation and a link to the official site. See <a href="/supported-platforms/">supported platforms</a>.</li>
  <li><strong>Expired or missing file:</strong> the host reported not found; ask the source for a new link.</li>
  <li><strong>Access denied:</strong> the file needs a login or blocks automated access. We do not bypass that.</li>
  <li><strong>Too large:</strong> files over the service limit are refused.</li>
  <li><strong>Timeout or unavailable:</strong> the source did not answer in time; try again later.</li>
</ul>
<p>More help is in the <a href="/how-to-download/">how-it-works guide</a>.</p>`,
  },
  {
    path: '/supported-platforms/',
    title: 'Supported Platforms and Limitations',
    h1: 'Supported Platforms',
    description: 'See exactly what this video download tool supports: direct HTTPS media files. Learn why YouTube, SoundCloud, TikTok and similar platforms are not supported.',
    lead: 'We list only what has been built and tested, and we explain what is deliberately left out.',
    body: `
<h2>Supported</h2>
<div class="table-wrap"><table>
<thead><tr><th>Source</th><th>What works</th><th>Limitations</th></tr></thead>
<tbody>
<tr><td><strong>Direct media files over HTTPS</strong></td><td>Links that point straight at audio or video files (MP4, WebM, MKV, MOV, MP3, M4A, OGG, WAV, FLAC and similar). We report the real file type and size when the host provides them and offer the original file for download.</td><td>No thumbnail, duration or resolution is available for plain files. Streaming playlists (.m3u8, .mpd) are rejected. Links that need a login or expire quickly may fail. The service refuses files over its size limit.</td></tr>
</tbody></table></div>
<p class="fine-print">The direct-file support has been tested with automated tests that simulate source responses. It has not been verified against every host on the internet, so some servers may behave differently.</p>

<h2>Not supported (on purpose)</h2>
<p>These platforms restrict downloading to their own official features. Pulling files out of them would mean getting around their access controls, which this site does not do.</p>
<div class="table-wrap"><table>
<thead><tr><th>Platform</th><th>What to use instead</th></tr></thead>
<tbody>
<tr><td>YouTube</td><td>YouTube Premium offline mode, or downloads enabled by the creator.</td></tr>
<tr><td>SoundCloud</td><td>The download button on tracks where the artist enabled it, or SoundCloud’s offline features.</td></tr>
<tr><td>TikTok</td><td>The Save video option on videos where the creator allows it.</td></tr>
<tr><td>Instagram, Facebook, X (Twitter)</td><td>No public download feature for other people’s posts. Ask the creator for the original file.</td></tr>
<tr><td>Vimeo</td><td>The Download button on the video page when the owner has enabled it.</td></tr>
<tr><td>Spotify, Netflix</td><td>DRM-protected. Use the official offline mode in the app.</td></tr>
<tr><td>Twitch</td><td>Broadcasters can download their own past broadcasts from their dashboard.</td></tr>
</tbody></table></div>
<p>If you paste one of these links, the tool tells you so and links to the official site. For anything not listed, only direct file links are attempted. See also the <a href="/copyright-policy/">copyright policy</a>.</p>`,
  },
  {
    path: '/how-to-download/',
    title: 'How to Download a Video from a Direct Link',
    h1: 'How It Works: Downloading from a Direct Link',
    description: 'Step-by-step guide to using the video download tool with direct media links, plus troubleshooting for expired, blocked or non-media links.',
    body: `
<h2>Step by step</h2>
<ol>
  <li>Find the <strong>direct file address</strong>. In most browsers you can right-click a video or audio player and choose “Copy video address” (or “Copy audio address”) if the site allows it. A direct link usually ends in a file type such as .mp4 or .mp3.</li>
  <li>Paste it into the box on the <a href="/video-downloader/">video downloader page</a>. Use the Paste button if your browser allows clipboard access.</li>
  <li>Select <strong>Analyze URL</strong>. The server checks the link and the file’s headers.</li>
  <li>If it is valid, choose <strong>Download</strong>. The original file opens from its host and your browser saves it.</li>
</ol>
<h2>On a phone</h2>
<p>Long-press a link to copy it, paste it into the field, and tap Analyze URL. Where the file is saved depends on your browser; on iPhone it is usually the Files app, and on Android the Downloads folder.</p>
<h2>Troubleshooting</h2>
<h3>“Not a media file”</h3>
<p>You pasted a page address, not a file address. Look for the file link itself.</p>
<h3>“Link may have expired”</h3>
<p>The host returned not found. Many hosts create temporary links; request a new one.</p>
<h3>“Access denied”</h3>
<p>The file needs you to be signed in, or the host blocks automated checks. We never use cookies or credentials, so this tool cannot open it.</p>
<h3>“Streaming playlist”</h3>
<p>An .m3u8 or .mpd link is a list of segments, not a single file, so it cannot be offered as a download here.</p>
<h3>The file plays instead of downloading</h3>
<p>Some browsers preview media. Right-click the Download button and choose “Save link as”, or long-press it on mobile.</p>
<h3>“Too large”</h3>
<p>The file is bigger than the limit the service allows to protect shared resources.</p>
<h2>Responsible use</h2>
<p class="notice">Only download media you own, have permission to save, or that is licensed for it. See the <a href="/disclaimer/">disclaimer</a>.</p>`,
  },
  {
    path: '/video-format-guide/',
    title: 'Video Format Guide: MP4, WebM, MKV, MOV and Audio',
    h1: 'Video Format Guide',
    description: 'A plain-language video format guide comparing MP4, WebM, MKV, MOV, MP3, AAC and more: compatibility, quality, file size and when to use each.',
    lead: 'A file format has two parts: the container (like MP4) that holds everything, and the codecs (like H.264) that compress the video and audio inside.',
    body: `
<h2>Video containers</h2>
<div class="table-wrap"><table>
<thead><tr><th>Format</th><th>Typical codecs</th><th>Best for</th><th>Notes</th></tr></thead>
<tbody>
<tr><td><strong>MP4</strong></td><td>H.264/AVC, H.265/HEVC, AV1 with AAC audio</td><td>Almost everything: phones, TVs, browsers, editing</td><td>The most compatible choice. HEVC and AV1 inside MP4 may not play on older devices.</td></tr>
<tr><td><strong>WebM</strong></td><td>VP8/VP9 or AV1 with Opus or Vorbis</td><td>Web video</td><td>Open format that browsers handle well. Less supported by older TVs and some editors.</td></tr>
<tr><td><strong>MKV</strong></td><td>Almost any</td><td>Archiving, multiple audio or subtitle tracks</td><td>Very flexible but not natively supported by many phones and web browsers.</td></tr>
<tr><td><strong>MOV</strong></td><td>H.264, HEVC, ProRes</td><td>Apple devices and editing workflows</td><td>Plays everywhere in the Apple ecosystem; ProRes files are very large.</td></tr>
<tr><td><strong>AVI</strong></td><td>Older codecs</td><td>Legacy files</td><td>Old container with limited modern feature support.</td></tr>
</tbody></table></div>
<h2>Audio formats</h2>
<div class="table-wrap"><table>
<thead><tr><th>Format</th><th>Type</th><th>Notes</th></tr></thead>
<tbody>
<tr><td>MP3</td><td>Lossy</td><td>Universal compatibility. Good at 192&ndash;320 kbps.</td></tr>
<tr><td>AAC / M4A</td><td>Lossy</td><td>Usually better quality than MP3 at the same bitrate.</td></tr>
<tr><td>OGG / Opus</td><td>Lossy</td><td>Efficient and open. Opus is excellent at low bitrates.</td></tr>
<tr><td>WAV</td><td>Uncompressed</td><td>Large files, ideal for editing.</td></tr>
<tr><td>FLAC</td><td>Lossless</td><td>Smaller than WAV with no quality loss.</td></tr>
</tbody></table></div>
<h2>Which should I choose?</h2>
<ul>
  <li>Sharing widely or playing on unknown devices: <strong>MP4 with H.264 and AAC</strong>.</li>
  <li>Embedding in a website: <strong>MP4 or WebM</strong>.</li>
  <li>Keeping many tracks in one file: <strong>MKV</strong>.</li>
  <li>Music for everyday listening: <strong>MP3 or AAC</strong>; for archiving: <strong>FLAC</strong>.</li>
</ul>
<p>Next, see how <a href="/video-bitrate-calculator/">bitrate</a> affects size and the <a href="/video-resolution-guide/">resolution guide</a>.</p>`,
  },
  {
    path: '/video-resolution-guide/',
    title: 'Video Resolution Guide: 480p, 720p, 1080p, 4K',
    h1: 'Video Resolution Guide',
    description: 'Understand video resolutions from 360p to 8K: pixel sizes, typical bitrates, file sizes and which resolution suits your screen and connection.',
    lead: 'Resolution is the number of pixels in each frame. More pixels can mean more detail, but also bigger files.',
    body: `
<h2>Common resolutions</h2>
<div class="table-wrap"><table>
<thead><tr><th>Name</th><th>Pixels (16:9)</th><th>Typical H.264 bitrate*</th><th>Good for</th></tr></thead>
<tbody>
<tr><td>360p</td><td>640 &times; 360</td><td>0.5&ndash;1 Mbps</td><td>Slow connections, small screens</td></tr>
<tr><td>480p (SD)</td><td>854 &times; 480</td><td>1&ndash;2.5 Mbps</td><td>Phones, data saving</td></tr>
<tr><td>720p (HD)</td><td>1280 &times; 720</td><td>2.5&ndash;5 Mbps</td><td>Laptops, casual viewing</td></tr>
<tr><td>1080p (Full HD)</td><td>1920 &times; 1080</td><td>5&ndash;10 Mbps</td><td>Most TVs and monitors</td></tr>
<tr><td>1440p (2K)</td><td>2560 &times; 1440</td><td>10&ndash;16 Mbps</td><td>Large monitors</td></tr>
<tr><td>2160p (4K)</td><td>3840 &times; 2160</td><td>20&ndash;45 Mbps</td><td>4K TVs, detailed footage</td></tr>
</tbody></table></div>
<p class="fine-print">*Rough, commonly used ranges. Actual needs depend on the codec, frame rate and how complex the footage is.</p>
<h2>Choosing a resolution</h2>
<ul>
  <li>Match the screen: a phone rarely benefits from more than 1080p.</li>
  <li>Higher frame rates (60 fps) need more bitrate than 30 fps at the same resolution.</li>
  <li>Upscaling a low resolution file does not add detail.</li>
</ul>
<p>Use the <a href="/video-aspect-ratio-calculator/">aspect ratio calculator</a> to resize without stretching, and the <a href="/video-file-size-calculator/">file size calculator</a> to see what a given bitrate costs in storage. For container choices, read the <a href="/video-format-guide/">video format guide</a>.</p>
<p>This tool shows resolution only when a source reports it. Direct file links normally do not, so the downloader does not display one.</p>`,
  },
  {
    path: '/video-file-size-calculator/',
    title: 'Video File Size Calculator',
    h1: 'Video File Size Calculator',
    description: 'Free video file size calculator. Enter duration and bitrates to estimate how big a video file will be. Runs entirely in your browser.',
    lead: 'Estimate file size from bitrate and duration. Everything is calculated in your browser; nothing is uploaded.',
    body: `
<form id="calc-size" class="calc" novalidate>
  ${timeFields}
  <div class="row">
    <div class="field"><label for="video">Video bitrate (kbps)</label><input id="video" name="video" type="number" min="0" step="any" value="5000" inputmode="decimal"></div>
    <div class="field"><label for="audio">Audio bitrate (kbps)</label><input id="audio" name="audio" type="number" min="0" step="any" value="128" inputmode="decimal"></div>
  </div>
  <div data-out role="status" aria-live="polite"></div>
</form>
<h2>How it works</h2>
<p>Size in bytes = (video kbps + audio kbps) &times; 1000 &times; seconds &divide; 8. For example, 10 minutes at 5,000 kbps video and 128 kbps audio is about 385 MB.</p>
<p>Results are estimates. Variable bitrate encoding, container overhead and subtitles change the final size. Sizes use decimal units (1 MB = 1,000,000 bytes); the MiB figure uses 1,048,576.</p>
<p>Need the reverse? Use the <a href="/video-bitrate-calculator/">bitrate calculator</a>.</p>`,
  },
  {
    path: '/video-bitrate-calculator/',
    title: 'Video Bitrate Calculator for a Target File Size',
    h1: 'Video Bitrate Calculator',
    description: 'Free video bitrate calculator: enter a target file size and duration to find the video bitrate that fits. Works offline in your browser.',
    lead: 'Work out the bitrate that fits a size limit, such as an email or upload cap.',
    body: `
<form id="calc-bitrate" class="calc" novalidate>
  ${timeFields}
  <div class="row">
    <div class="field"><label for="size">Target size</label><input id="size" name="size" type="number" min="0" step="any" value="100" inputmode="decimal"></div>
    <div class="field"><label for="unit">Unit</label><select id="unit" name="unit"><option value="MB">MB</option><option value="GB">GB</option></select></div>
    <div class="field"><label for="audio">Audio bitrate (kbps)</label><input id="audio" name="audio" type="number" min="0" step="any" value="128" inputmode="decimal"></div>
  </div>
  <div data-out role="status" aria-live="polite"></div>
</form>
<h2>How it works</h2>
<p>Total bitrate = target size &times; 8 &divide; duration. We subtract the audio bitrate, and what remains is the video bitrate. Use a value a few percent lower to leave room for container overhead.</p>
<p>Once you have a bitrate, check it against the <a href="/video-resolution-guide/">resolution guide</a>: if the bitrate is very low for your resolution, pick a lower resolution rather than accepting blocky video. To see the size from a bitrate, use the <a href="/video-file-size-calculator/">file size calculator</a>.</p>`,
  },
  {
    path: '/video-aspect-ratio-calculator/',
    title: 'Video Aspect Ratio Calculator',
    h1: 'Video Aspect Ratio Calculator',
    description: 'Free video aspect ratio calculator. Find the ratio of any resolution and get the matching height for a new width. Runs in your browser.',
    lead: 'Find the aspect ratio of a video and resize it without stretching.',
    body: `
<form id="calc-aspect" class="calc" novalidate>
  <div class="row">
    <div class="field"><label for="w">Width (px)</label><input id="w" name="w" type="number" min="1" step="1" value="1920" inputmode="numeric"></div>
    <div class="field"><label for="h">Height (px)</label><input id="h" name="h" type="number" min="1" step="1" value="1080" inputmode="numeric"></div>
    <div class="field"><label for="newWidth">New width (optional)</label><input id="newWidth" name="newWidth" type="number" min="1" step="1" value="1280" inputmode="numeric"></div>
  </div>
  <div data-out role="status" aria-live="polite"></div>
</form>
<h2>Common aspect ratios</h2>
<ul>
  <li><strong>16:9</strong> &ndash; standard widescreen (1920&times;1080, 1280&times;720).</li>
  <li><strong>9:16</strong> &ndash; vertical video for phones.</li>
  <li><strong>4:3</strong> &ndash; older TVs and some tablets.</li>
  <li><strong>1:1</strong> &ndash; square.</li>
  <li><strong>21:9</strong> &ndash; ultrawide and cinema-style.</li>
</ul>
<p>Heights are rounded to even numbers because most video codecs require even dimensions. See the <a href="/video-resolution-guide/">resolution guide</a> for standard sizes.</p>`,
  },
  {
    path: '/blog/',
    title: 'Blog: Practical Video and Audio File Guides',
    h1: 'Blog',
    description: 'Original, practical articles about video file size, bitrate, formats and responsible downloading from the DownCloud Tools team.',
    lead: 'Short, practical articles about working with video and audio files.',
    body: `
<div class="grid">
  <article class="card"><h2><a href="/blog/how-bitrate-affects-video-file-size/">How bitrate affects video file size</a></h2><p>Why two videos of the same length can differ ten times in size, and how to estimate it yourself.</p></article>
  <article class="card"><h2><a href="/blog/choosing-a-video-format/">Choosing a video format without the jargon</a></h2><p>A simple way to pick between MP4, WebM and MKV for your situation.</p></article>
</div>`,
  },
  {
    path: '/blog/how-bitrate-affects-video-file-size/',
    parent: ['/blog/', 'Blog'],
    schema: 'article',
    date: UPDATED,
    title: 'How Bitrate Affects Video File Size',
    h1: 'How Bitrate Affects Video File Size',
    description: 'Learn how bitrate, duration and audio determine video file size, with a worked example and tips for hitting an upload limit.',
    body: `
<p>Two ten-minute videos can be 60 MB or 600 MB. The difference is almost always <strong>bitrate</strong>: how many bits are used for each second of video.</p>
<h2>The basic formula</h2>
<p>File size is roughly bitrate multiplied by duration. Video and audio add together. A ten-minute clip at 5 Mbps video and 128 kbps audio uses about 5,128 kbps &times; 600 s &divide; 8, or roughly 385 MB.</p>
<h2>Why resolution alone does not decide size</h2>
<p>Resolution is the number of pixels, bitrate is how much data describes them. A 1080p video at 2 Mbps will be small but may look soft or blocky; a 720p video at the same bitrate often looks cleaner because there are fewer pixels to describe.</p>
<h2>Fitting a size limit</h2>
<ol>
  <li>Decide the target size, for example 25 MB.</li>
  <li>Divide by duration to find the total bitrate.</li>
  <li>Subtract audio (96&ndash;128 kbps is usually fine for speech).</li>
  <li>Leave a few percent for container overhead.</li>
</ol>
<p>The <a href="/video-bitrate-calculator/">video bitrate calculator</a> does these steps for you, and the <a href="/video-file-size-calculator/">file size calculator</a> checks the result.</p>
<p>Variable bitrate encoders spend more bits on busy scenes and fewer on still ones, so the real file will differ from the estimate.</p>`,
  },
  {
    path: '/blog/choosing-a-video-format/',
    parent: ['/blog/', 'Blog'],
    schema: 'article',
    date: UPDATED,
    title: 'Choosing a Video Format Without the Jargon',
    h1: 'Choosing a Video Format Without the Jargon',
    description: 'A short, practical guide to choosing between MP4, WebM and MKV, and why the codec inside the file matters as much as the container.',
    body: `
<p>People say “format” when they mean two things: the <strong>container</strong> (the file type, like MP4) and the <strong>codec</strong> (how the picture is compressed, like H.264). Most compatibility problems come from the codec.</p>
<h2>If you only remember one thing</h2>
<p>Use <strong>MP4 with H.264 video and AAC audio</strong>. It plays on nearly every phone, TV, browser and editor.</p>
<h2>When to choose something else</h2>
<ul>
  <li><strong>WebM</strong> for web pages where you want an open format with good compression.</li>
  <li><strong>MKV</strong> when you need several audio tracks or subtitle tracks in one file.</li>
  <li><strong>MOV</strong> when you work inside an Apple editing workflow.</li>
</ul>
<h2>Newer codecs</h2>
<p>HEVC and AV1 make smaller files at the same quality, but older devices may not decode them. If a video will not play but the file type looks right, an unsupported codec is the most likely cause.</p>
<p>For a side-by-side comparison, read the <a href="/video-format-guide/">video format guide</a>. To see how much space a format choice can save, try the <a href="/video-file-size-calculator/">file size calculator</a>.</p>`,
  },
  {
    path: '/about/',
    title: 'About DownCloud Tools',
    h1: 'About Us',
    description: 'About DownCloud Tools: who runs it, what the tools do, what they deliberately do not do, and how to reach us.',
    body: `
<p>DownCloud Tools is an independent website that helps people check links to audio and video files and work out practical details about them, such as file size, bitrate and aspect ratio.</p>
<h2>What we do</h2>
<ul>
  <li>Check direct links to media files and offer the original file for download.</li>
  <li>Provide free calculators that run in your browser.</li>
  <li>Publish plain-language guides about formats and resolution.</li>
</ul>
<h2>What we do not do</h2>
<ul>
  <li>We do not extract media from platforms that restrict downloading.</li>
  <li>We do not bypass logins, paywalls or DRM.</li>
  <li>We do not show made-up statistics, reviews or user counts.</li>
</ul>
<h2>Ownership and contact</h2>
<p>The site is operated by its owner under the name DownCloud Tools. Reach us at ${mail}. See also the <a href="/contact/">contact page</a>.</p>
<p>DownCloud Tools is not affiliated with, endorsed by, or sponsored by any media platform.</p>`,
  },
  {
    path: '/contact/',
    title: 'Contact DownCloud Tools',
    h1: 'Contact Us',
    description: 'Contact DownCloud Tools for support, feedback, copyright notices or privacy questions.',
    body: `
<p>Email is the best way to reach us: ${mail}.</p>
<h2>What to include</h2>
<ul>
  <li><strong>Support:</strong> the page you used and a description of the problem. Please do not send private or signed links.</li>
  <li><strong>Copyright notices:</strong> follow the steps in the <a href="/copyright-policy/">copyright policy</a>.</li>
  <li><strong>Privacy requests:</strong> see the <a href="/privacy-policy/">privacy policy</a>.</li>
</ul>
<p class="notice">We cannot help download content from platforms that do not allow it. See <a href="/supported-platforms/">supported platforms</a> for what is possible.</p>`,
  },
  {
    path: '/faq/',
    title: 'FAQ: Video Downloader and Media Tools',
    h1: 'Frequently Asked Questions',
    description: 'Answers about the DownCloud Tools video downloader: what is supported, why some links fail, privacy, file size and responsible use.',
    faq,
    body: `${faqHtml}\n<p>Still stuck? Read <a href="/how-to-download/">how it works</a> or <a href="/contact/">contact us</a>.</p>`,
  },
  {
    path: '/privacy-policy/',
    title: 'Privacy Policy',
    h1: 'Privacy Policy',
    description: 'How DownCloud Tools handles the links you submit, what is logged, what is stored in your browser, and your choices.',
    body: `
<p>Last updated: ${UPDATED}</p>
<h2>What we process</h2>
<p><strong>Links you analyze.</strong> When you select Analyze URL, the link is sent to our server. The server contacts the link’s host to read the file’s headers (type and size). The link is used only for that request and is not saved in a database.</p>
<p><strong>Calculators and guides.</strong> The calculators run entirely in your browser. Nothing you type into them is sent to us.</p>
<h2>What is logged</h2>
<p>Our server and hosting providers may record standard technical data such as IP address, time and request status for security and abuse prevention (for example rate limiting). Application logs do not record the full submitted URL or its query string.</p>
<h2>What is stored in your browser</h2>
<p>Your light or dark theme choice is stored in your browser’s local storage. See the <a href="/cookie-policy/">cookie policy</a>.</p>
<h2>Accounts, analytics and ads</h2>
<p>No account is needed. At the time of writing the site uses no analytics and shows no ads. If that changes, this policy will be updated and any required consent will be requested first.</p>
<h2>Third parties</h2>
<p>The hosts of links you analyze receive a request from our server and will see our server’s address, not yours. Files you download come directly from the host to your browser, so that host will see your address.</p>
<h2>Your choices and contact</h2>
<p>You can clear stored data in your browser at any time. For privacy questions, contact ${mail}.</p>`,
  },
  {
    path: '/terms-and-conditions/',
    title: 'Terms and Conditions',
    h1: 'Terms and Conditions',
    description: 'The terms for using DownCloud Tools, including acceptable use, copyright responsibility and limits of liability.',
    body: `
<p>Last updated: ${UPDATED}</p>
<h2>Using the service</h2>
<p>By using DownCloud Tools you agree to these terms. If you do not agree, please do not use the site.</p>
<h2>Acceptable use</h2>
<ul>
  <li>Use the tools only with content you own, have permission to save, or are legally allowed to download.</li>
  <li>Do not use the service to violate copyright, license terms, platform terms, privacy or any law.</li>
  <li>Do not try to attack, overload or probe internal networks through the service, or to evade its limits.</li>
</ul>
<h2>Your responsibility</h2>
<p>You are solely responsible for how you use files you download and for complying with the rights of their owners.</p>
<h2>No guarantees</h2>
<p>The service is provided as is, without warranties. Links may fail for reasons outside our control. We may change or stop features, or limit usage, at any time.</p>
<h2>Limitation of liability</h2>
<p>To the extent permitted by law, we are not liable for losses arising from use of the site or from content you download.</p>
<h2>Contact</h2>
<p>${mail}</p>`,
  },
  {
    path: '/disclaimer/',
    title: 'Disclaimer',
    h1: 'Disclaimer',
    description: 'Disclaimer for DownCloud Tools: no affiliation with media platforms, no hosted content, and responsible use of downloaded files.',
    body: `
<p>Last updated: ${UPDATED}</p>
<ul>
  <li><strong>No affiliation.</strong> DownCloud Tools is independent and is not affiliated with, endorsed by, or sponsored by YouTube, SoundCloud, TikTok, Instagram, Spotify or any other platform. Their names appear only to explain what is not supported.</li>
  <li><strong>No hosted media.</strong> We do not host, store or distribute media files. Downloads come from the source’s own server.</li>
  <li><strong>Permission matters.</strong> Only download content you own, have permission to save, or that is licensed for it.</li>
  <li><strong>Estimates.</strong> Calculator results are estimates and may differ from real files.</li>
  <li><strong>Accuracy.</strong> We work to keep information correct, but formats, platforms and rules change.</li>
</ul>
<p>See also the <a href="/terms-and-conditions/">terms</a> and <a href="/copyright-policy/">copyright policy</a>.</p>`,
  },
  {
    path: '/copyright-policy/',
    title: 'Copyright Policy',
    h1: 'Copyright Policy',
    description: 'DownCloud Tools respects intellectual property. Read how we limit supported sources and how to send a copyright notice.',
    body: `
<p>Last updated: ${UPDATED}</p>
<h2>Our approach</h2>
<p>We respect intellectual property rights. The service does not host media, does not extract from platforms that restrict downloading, and does not bypass DRM, paywalls or access controls.</p>
<h2>User responsibility</h2>
<p>You must have the right to download any file you save. Copyright, licensing and platform terms apply to you.</p>
<h2>Sending a copyright notice</h2>
<p>If you believe a link or file handled through this site infringes your rights, email ${mail} with:</p>
<ol>
  <li>Your name and contact details.</li>
  <li>A description of the work you own.</li>
  <li>The link in question.</li>
  <li>A statement that you believe in good faith the use is not authorized.</li>
  <li>A statement that your notice is accurate and that you are the owner or authorized to act for them.</li>
</ol>
<p>Because files are served by their own hosts, you may also need to contact the host directly. We will review notices and may block specific sources.</p>`,
  },
  {
    path: '/cookie-policy/',
    title: 'Cookie Policy',
    h1: 'Cookie Policy',
    description: 'What DownCloud Tools stores in your browser: only your theme preference. No tracking or advertising cookies are currently set.',
    body: `
<p>Last updated: ${UPDATED}</p>
<h2>What we store</h2>
<table>
<thead><tr><th>Name</th><th>Where</th><th>Purpose</th><th>Lifetime</th></tr></thead>
<tbody><tr><td>theme</td><td>Local storage</td><td>Remembers your dark or light mode choice.</td><td>Until you clear your browser data</td></tr></tbody>
</table>
<h2>Cookies</h2>
<p>This site does not currently set tracking, analytics or advertising cookies. Our hosting providers may use technically necessary cookies or logs for security.</p>
<h2>If this changes</h2>
<p>If we add analytics or advertising, we will list them here and ask for consent where required before they run.</p>
<h2>Control</h2>
<p>You can clear local storage and cookies in your browser settings at any time. See the <a href="/privacy-policy/">privacy policy</a>.</p>`,
  },
  {
    path: '/404.html',
    title: 'Page Not Found',
    h1: 'Page Not Found',
    description: 'The page you requested could not be found.',
    noindex: true,
    noAds: true,
    body: `<p>That page does not exist or has moved. Try the <a href="/">home page</a>, the <a href="/video-downloader/">video downloader</a>, or the <a href="/faq/">FAQ</a>.</p>`,
  },
];
