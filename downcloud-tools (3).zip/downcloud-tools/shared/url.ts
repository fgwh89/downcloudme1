// URL validation shared by the browser and the server.
// The client uses it for fast feedback; the server ALWAYS re-validates.

export type UrlCheck = { ok: true; url: URL } | { ok: false; error: string };

const BLOCKED_SUFFIXES = ['.local', '.localhost', '.internal', '.lan', '.home', '.corp'];

export function validateMediaUrl(input: string): UrlCheck {
  const value = (input ?? '').trim();
  if (!value) return { ok: false, error: 'Please paste a URL first.' };
  if (value.length > 2048) return { ok: false, error: 'That URL is too long.' };

  let url: URL;
  try {
    url = new URL(value);
  } catch {
    return { ok: false, error: 'That does not look like a valid URL. Include the full address, starting with https://' };
  }

  if (url.protocol !== 'https:') return { ok: false, error: 'Only secure https:// links are supported.' };
  if (url.username || url.password) return { ok: false, error: 'URLs that contain a username or password are not accepted.' };
  if (url.port && url.port !== '443') return { ok: false, error: 'Only the standard HTTPS port is supported.' };

  const host = url.hostname.toLowerCase();
  const isIpLiteral = /^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.startsWith('[');
  if (isIpLiteral) return { ok: false, error: 'Please use a web address with a domain name, not a raw IP address.' };
  if (!host.includes('.') || host === 'localhost' || BLOCKED_SUFFIXES.some((s) => host.endsWith(s))) {
    return { ok: false, error: 'That address is not a public website.' };
  }
  return { ok: true, url };
}
