// Pure calculation helpers. Everything here runs in the browser; nothing is sent to a server.

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '—';
  const units = ['B', 'KB', 'MB', 'GB', 'TB'];
  let v = bytes;
  let i = 0;
  while (v >= 1000 && i < units.length - 1) {
    v /= 1000;
    i++;
  }
  return `${v >= 100 || i === 0 ? v.toFixed(0) : v.toFixed(2)} ${units[i]}`;
}

export function formatDuration(totalSeconds: number): string {
  const s = Math.round(totalSeconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(sec)}` : `${m}:${pad(sec)}`;
}

export function toSeconds(h: number, m: number, s: number): number {
  return h * 3600 + m * 60 + s;
}

/** Estimated file size in bytes from bitrates (kilobits per second, 1 kbps = 1000 bit/s). */
export function estimateFileSizeBytes(videoKbps: number, audioKbps: number, seconds: number): number {
  return ((videoKbps + audioKbps) * 1000 * seconds) / 8;
}

/** Video bitrate (kbps) that fits a target size, after reserving the audio track. Returns null when impossible. */
export function videoBitrateForSize(targetBytes: number, seconds: number, audioKbps: number): number | null {
  if (!(seconds > 0) || !(targetBytes > 0)) return null;
  const totalKbps = (targetBytes * 8) / seconds / 1000;
  const video = totalKbps - audioKbps;
  return video > 0 ? video : null;
}

export function gcd(a: number, b: number): number {
  a = Math.abs(Math.round(a));
  b = Math.abs(Math.round(b));
  while (b) [a, b] = [b, a % b];
  return a;
}

export function aspectRatio(width: number, height: number): { w: number; h: number; decimal: number } | null {
  if (!(width > 0) || !(height > 0)) return null;
  const g = gcd(width, height);
  return { w: Math.round(width) / g, h: Math.round(height) / g, decimal: width / height };
}

/** Height for a new width that keeps the ratio; rounded to an even number, as most codecs require. */
export function scaledHeight(width: number, height: number, newWidth: number): number | null {
  if (!(width > 0) || !(height > 0) || !(newWidth > 0)) return null;
  const raw = (newWidth * height) / width;
  return Math.max(2, Math.round(raw / 2) * 2);
}
