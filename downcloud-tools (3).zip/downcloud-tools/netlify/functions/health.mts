import type { Config } from '@netlify/functions';

export default async (): Promise<Response> =>
  new Response(JSON.stringify({ ok: true }), {
    headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
  });

export const config: Config = { path: '/api/health', method: ['GET'] };
