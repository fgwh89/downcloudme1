import type { Config, Context } from '@netlify/functions';
import { createAnalyzeHandler } from '../../server/src/handler';

// Created once per function instance and reused across warm invocations.
const handle = createAnalyzeHandler();

export default async (req: Request, context: Context): Promise<Response> => handle(req, context.ip);

export const config: Config = {
  path: '/api/analyze',
  method: ['POST'],
};
